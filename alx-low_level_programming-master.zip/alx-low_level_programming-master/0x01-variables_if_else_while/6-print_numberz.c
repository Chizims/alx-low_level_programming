#include <stdio.h>

/**
* main - This code prints numbers 1 - 10
* Return: always 0, successful.
*/
int main(void)
{
	int x;

	for (x = 48; x < 58; x++)
	{
	putchar(x);
	}
	putchar('\n');
	return (0);
}
