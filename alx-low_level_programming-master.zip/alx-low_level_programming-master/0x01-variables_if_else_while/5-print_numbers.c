#include <stdio.h>

/**
* main - This code prints numbers 1 - 10
* Return: always 0, successful.
*/
int main(void)
{
	int x = 0;

	for (x = 0; x < 10; x++)
	{
	printf("%d", x);
	};
	printf("\n");
	return (0);
}
