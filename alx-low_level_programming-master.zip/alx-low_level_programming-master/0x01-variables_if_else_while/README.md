in this project, I will be writting some C code lines on Variables, if, else, while
